export const MOCK_USER = {
  id: '12345',
  name: 'Salman Hanfi',
  email: 'salmanhanfi1437@gmail.com',
  password: '123456',
};
