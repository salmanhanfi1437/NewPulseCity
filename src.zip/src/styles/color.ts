const colors = {
  primary: '#2B7AFA',
  secondary: '#6C63FF',
  white: '#FFFFFF',
  text: '#222222',
  gray: '#888888',
  lightGray: '#E5E5E5',
  danger: '#FF4C4C',
  success: '#28A745',
};

export default colors;