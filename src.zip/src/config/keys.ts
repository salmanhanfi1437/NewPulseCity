// src/config/keys.ts
export const TICKETMASTER_API_KEY = 'JhFxoWhZQZGaJYcTZtvtf1lmG4rJGCZF';
export const GOOGLE_MAPS_API_KEY = '';
